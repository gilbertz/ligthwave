/* src/config.h.  Generated automatically by configure.  */
#define	HAVE_MD5	1
#define HAVE_TYPES	0
#define HAVE_SOCKET	0
#define HAVE_NETDB	0
#define HAVE_NETINET	0
