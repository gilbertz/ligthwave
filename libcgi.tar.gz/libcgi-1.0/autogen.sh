#!/bin/bash

for i in `/usr/bin/which autoconf`; do
	$i
done

